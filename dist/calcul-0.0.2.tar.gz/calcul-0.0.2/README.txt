Calculator that takes a string as input
